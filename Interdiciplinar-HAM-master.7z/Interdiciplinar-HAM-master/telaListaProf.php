
 <!DOCTYPE html>
 <html lang="en" dir="ltr">
   <head>
     <meta charset="utf-8">
     <title>TELA DE CADASTRO DE Professo</title>
   <link rel="stylesheet" href="css/bootstrap.min.css">
   <link rel="stylesheet" href="datatable/datatables.min.css">


 </head>
   <body>
     <div class="container">

       <!-- Inclui o menu neste lugar -->
      <div class="row bg-secondary">
        <div class="col-md">
            <h3 class="ml-2 text-light m-4 ">PROJETO HAM </h3>
          </div>
      </div>

        <div class="row">
          <div class="col-md mx-auto py-5">

           <h3>LISTA DE CADASTRADOS</h3>
           <hr>

           <?php
           include 'conexao.php';
           include 'partes/config.php';


           $select = mysqli_query($con,"SELECT * FROM cadprof");
           $array = mysqli_fetch_array($select);

            ?>

            <table id="teste" class="table table-striped table-bordered bg-secondary" style="width:100%">
              <thead>
                <tr>
                  <th>Nome</th>
                  <th>SIAP</th>
                  <th>e-mail</th>



              </tr>
            </thead>
            <tbody>
              <?php while ($array = mysqli_fetch_assoc($select)) {?>
              <tr>
                <td><?php echo $array['nome']; ?></td>
                <td><?php echo $array['email']; ?></td>
                <td><?php echo $array['ciap']; ?></td>

                <td>
                  <form class="" action="/Interdiciplinar-HAM-master/alterarProf.php" method="post">
                      <input type="hidden" name="nome" value="<?php echo $array['nome'] ?>">
                      <input type="hidden" name="ciap" value="<?php echo $array['ciap'] ?>">
                      <input type="hidden" name="email" value="<?php echo $array['email'] ?>">

                      <button type="submit" class="mt-3 btn btn-dark" id="btnEntrar">
                      Alterar
                    </button>
                  </form>
                </td>
                <td>
                  <form class="" action="/Interdiciplinar-HAM-master/excluirProf.php" method="post">
                    <!-- <input type="hidden" name="idaluno" value="<?php echo $array['idCadProf'] ?>">
                      <input type="hidden" name="nome" value="<?php echo $array['nome'] ?>">
                      <input type="hidden" name="ra" value="<?php echo $array['ciap'] ?>"> -->
                      <input type="hidden" name="email" value="<?php echo $array['email'] ?>">

                      <button type="submit" class="mt-3 btn btn-danger" id="btnEntrar">
                      Excluir
                    </button>
                  </form>
                </td>
                <td></td>
              </tr>
            <?php } ?>
           </tbody>
            </table>

         </div>
       </div>
     </div>

     <!-- "Importa" os códigos/bibliotecas javascript -->
      <?php include 'partes/javascript.php' ?>


      <script>
      $(document).ready( function () {
        $('#teste').DataTable();
      } );
      </script>


   </body>
 </html>
