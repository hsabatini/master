<?php
include "conexao.php";
@SESSION_START();

$id = $_POST['idaluno'];
$email = $_POST['email'];
$curso = $_POST['curso'];

$update_nome = "UPDATE cadaluno set email='$email', curso='$curso' WHERE idCadAluno='$id'";
$result = mysqli_query($con, $update_nome) or die ('Failed to query database. <br>'.mysqli_error($con));
include "telaLista.php";

?>
