<?php

define ('Host', 'localhost');
define ('user', 'root');
define ('pass', '');
define ('banco', 'inter');



?>
