<div class="row bg-secondary">
  <div class="col-md">
    <h3 class="ml-2 text-light m-4 ">PROJETO HAM </h3>
  </div>
  <div class="col-md pl-5 pt-2 pb-3">
    <img src="http://200.17.98.122:8080/certificadosdeclaracoes/resources/img/paranavai-vertical.png" alt="" height="50">
  </div>
</div>

<div class="row bg-secondary p-2">
<div class="col-md">
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="#"> </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNavDropdown">
      <ul class="navbar-nav">
        <li class="nav-item">
          <!-- <a class="nav-link" href="#">Cadastrar Professor</a> -->
          <a href="/Interdiciplinar-HAM-master/cadaluno.php" class="btn btn-light" id="btnCadastro">
            Cadastrar
          </a>
        </li>
        <li class="nav-item">
          <!-- <a class="nav-link" href="#">Cadastrar Monitor</a> -->
          <a href="/Interdiciplinar-HAM-master/telaLista.php" class="btn btn-light" id="btnCadastro">
            Fazer!!
          </a>
        </li>
        <li class="nav-item">
          <!-- <a class="nav-link" href="#">Cadastrar Monitor</a> -->
          <a href="/Interdiciplinar-HAM-master/telaLogin.php" class="btn btn-light" id="btnCadastro">
            Login
          </a>
        </li>

      </ul>
    </div>
  </nav>

</div>
</div>
