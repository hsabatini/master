<?php
include "conexao.php";
@SESSION_START();

$id = $_POST['idprof'];
$email = $_POST['email'];
$ciap = $_POST['ciap'];

$update_nome = "UPDATE cadprof set email='$email', ciap='$ciap' WHERE idCadAluno='$id'";
$result = mysqli_query($con, $update_nome) or die ('Failed to query database. <br>'.mysqli_error($con ));
include "telaListaProf.php";

?>
