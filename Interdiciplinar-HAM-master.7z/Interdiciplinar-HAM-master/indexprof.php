<?php

$get = isset ($_GET ['pagina'])? $_GET['pagina']: '';
require 'partes/funcsProf.php';
require 'partes/config.php';
require "telaCadastro.php";
nageva ($get);

?>
