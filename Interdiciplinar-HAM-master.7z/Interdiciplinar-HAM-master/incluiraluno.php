<table border="0" cellpadding=0 cellspacing=0>
  <tr> <td colspan="2" align='center'> Cadastro de alunos </td></tr>
  <form action="?pagina=gravaraluno" method="post">
  <tr>
    <td width="80 px"> Nome: </td>
    <td> <iput id="nome" nome="nome" type="text" require> </td>
  </tr>
  <tr>
    <td width="80 px"> : </td>
    <td> <iput id="ra" ra="ra" type="text" require> </td>
  </tr>
  <tr align="center">
    <td><button type="submit">Gravar</button></td>
    <td><button type="submit">Cancelar</button></td>
  </tr>
</form>
</table>
