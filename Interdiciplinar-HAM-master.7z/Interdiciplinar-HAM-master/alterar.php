<?php
@session_start();
include "conexao.php";
$_SESSION['email'] = $_POST['email'];
$_SESSION['curso'] = $_POST['curso'];
$email = $_POST['email'];
$curso = $_POST['curso'];

$seletor = "SELECT * FROM cadaluno WHERE email = '$email' AND curso = '$curso'";
$res = mysqli_query($con, $seletor);
$select = mysqli_fetch_assoc($res);

?>

            <form action="alterar2.php" name="form" method="post" class="pl-5 pt-5 pb-5 text-left w-50">
              <label>email: </label>
              <input type="text" name="email" value="<?php echo $select['email'];?>" required ><br>
              <label>curso: </label>
              <input type="text" name="curso" value="<?php echo $select['curso'];?>" required ><br>

              <div class="text-center pr-5">
                <input type="hidden" name='idaluno' value="<?php echo $select['idCadAluno']; $select['email']; $select['curso']; ?>" class="p-2 mt-1 btn-danger"></input>
                <button type="submit" name="button">Alterar</button>
    
              </div>
            </form>
            <br>

            <br>
            <div class="p-4 m-4">

            </div>

</html>
