<?php
include "conexao.php";
$nome = $_POST['nome'];
$email = $_POST['email'];
$senha = $_POST['senha'];
$confSenha = $_POST['confSenha'];
$ra = $_POST['ra'];
$curso = $_POST['curso'];
$turma = $_POST['turma'];

$select_aluno = "SELECT * FROM cadaluno";
$result = mysqli_query($con, $select_aluno);
$array = mysqli_fetch_array($result);

if($array['nome'] == $nome){
  //primeiro condicao e depois eu inseri

}else {
  if($senha == $confSenha){

    $inserir = "INSERT INTO cadaluno (nome, email, senha, confSenha, ra, curso, turma ) VALUES ('$nome', '$email', '$senha', '$confSenha', '$ra', '$curso', '$turma' )";

    mysqli_query($con, $inserir);
  } else{
    echo "Senha incorreta";
  }
  // alert("Cadastrado com sucesso!");
  include "cadaluno.php";
}

 ?>
