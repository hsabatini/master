<!DOCTYPE html>
<html lang="" dir="ltr">
<head>
<meta charset="utf-8">
<title> TELA INICIAL </title>
<?php include 'partes/head.php' ?>
</head>
<body>
<div class="container">

  <!-- Inclui o menu/link neste lugar -->
  <?php include 'partes/menuAluno.php' ?>

    <!-- Inclui o carrosel neste lugar -->
  <?php include 'partes/carrosel.php' ?>



<?php include 'partes/rodape.php' ?>

</div>

<!-- "Importa" os códigos/bibliotecas javascript -->
<?php include 'partes/javascript.php' ?>
<script type="text/javascript">
    $(document).ready(function(){
      // Aqui vai seu código js/jquery

    });
</script>

</body>
</html>
