<?php
include "conexao.php";
$disciplina = $_POST['disciplina:'];
$horario = $_POST['horario:'];
$bloco = $_POST['bloco:'];
$sala = $_POST['sala:'];


$select_cadmonitor = "SELECT * FROM infomoni";
$result = mysqli_query($con, $select_infomoni);
$array = mysqli_fetch_array($result);

if($array['Disciplina'] == $disciplina){
  // alert("Usuário já cadastrado!");
}else {
      $inserir = "INSERT INTO infomoni (disciplina, horario, bloco, sala) VALUES ('$disciplina', '$horario', '$bloco', '$sala' )";

    mysqli_query($con, $inserir);
  }
  // alert("Cadastrado com sucesso!");
  include "horarioMoni.php";
}

 ?>
