<?php

$get = isset ($_GET ['pagina'])? $_GET['pagina']: '';
include 'partes/funcs.php';
include 'partes/config.php';
include "telaCadastro.php";
// navega($get);

?>
