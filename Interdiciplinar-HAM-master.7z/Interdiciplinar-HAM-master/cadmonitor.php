<?php include 'partes/cabeca.php' ?>
  <body>
    <div class="container">

      <div class="row">
        <div class="col-md-4 mx-auto py-5">
          <h3>Cadastro de Monitor</h3>
          <hr>
          <form action="" method="post" id="formulario">

            <label>Nome:</label><br>
            <input type="text" name="nome" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <label>Email:</label><br>
            <input type="email" name="email" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <label>RA:</label><br>
            <input type="number" name="ra" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <label>Senha:</label><br>
            <input type="password" name="senha" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <label>Confirmar senha:</label><br>
            <input type="password" name="confsenha" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
<br>

            <a href="/Interdiciplinar-HAM-master/horarios/hrMonitoria.php" class="btn btn-secondary" id="btnHrMonitoria">
              Confirmar cadastro
            </a>

                <!-- "Importa" os códigos/bibliotecas javascript -->
                <?php include 'partes/javascript.php' ?>

                <script type="text/javascript">
                    $(document).ready(function(){
                      // Aqui vai seu código js/jquery

                    });
                </script>
  </body>
</html>
