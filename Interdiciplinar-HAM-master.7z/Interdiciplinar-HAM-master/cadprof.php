<?php include 'partes/cabeca.php' ?>
  <body>

    <div class="container">


            </div>
      <div class="row">
        <div class="col-md-4 mx-auto py-5">

          <h3>Cadastro de Professor</h3>
          <hr>

          <!-- PRECISAMOS DEFINIR - get ou post -->
          <form action="verificarprof.php" method="post" id="formulario">

            <label>Nome:</label><br>
            <input type="text" name="nome" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <label>Email:</label><br>
            <input type="email" name="email" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <label>CIAP:</label><br>
            <input type="text" name="ciap" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <!-- <label>Disciplina(as):</label><br>
            <input type="text" name="disciplina" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br> -->


            <label>Senha:</label><br>
            <input type="password" name="senha" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <label>Confirmar senha:</label><br>
            <input type="password" name="confSenha" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>


            <!-- Adicionar um do lado do outro!!! -->


            <button type="submit" class="btn btn-secondary" id="btnHrAtendimento">
             Confirmar cadastro
           </button>
          </form>
    </div>
    </div>
    </div>
    <!-- "Importa" os códigos/bibliotecas javascript -->
    <?php include 'partes/javascript.php' ?>

    <script type="text/javascript">
        $(document).ready(function(){
          // Aqui vai seu código js/jquery

        });
    </script>

  </body>
</html>
