<?php
include "conexao.php";
@SESSION_START();

// $id = $_POST['idaluno'];
$email = $_POST['email'];
// $curso = $_POST['curso'];

$delete_nome = "DELETE FROM cadaluno WHERE email='$email'";
$result = mysqli_query($con, $delete_nome) or die ('Failed to query database. <br>'.mysqli_error($con));
include "telaLista.php";

?>
