<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>

//Adicionar a tabela com os dados salvos no banco com o horario de monitoria
<?php
$con = conecta ( );
$res = mysqli_query ($con, 'SELECT * FROM atendimento');
?>
<table border="1" cellpadding=0 cellspacing=0>
  <tr> <td colspan="4" align='center'> Horários de atendimento </td></tr>
  <tr>
    <td> Hórario </td>
    <td> data </td>
    <td colspan="2" align="center"> Ações </td>
  </tr>
  <?php while ($atendimento= mysqli_fetch_assoc($res)): ?>
  <tr>
    <td><?php echo $atendimento['horario'];?> </td>
    <td><?php echo $atendimento['data'];?> </td>
    <td> Alterar </td>
  </tr>
<?php endwhile;?>
  </table>


  <div class="row bg-secondary">
    <div class="col-md ml-2 text-light m-4">
      <h4 class="ml-2 text-light m-4 "> Endereço: Rua, Avenida José Felipe Tequinha, 1400 - Jardim das Nacoes, Paranavaí - PR
Telefone: (44) 3482-0110</h4>
    </div>
  </div>

</body>
</html>
