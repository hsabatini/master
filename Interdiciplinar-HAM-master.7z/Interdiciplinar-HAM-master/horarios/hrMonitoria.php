<!DOCTYPE html>
<html lang="br" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>TELA DO HORÁRIO DE MONITORIA</title>
  <link rel="stylesheet" href="../css/bootstrap.min.css">

  </head>
  <body>

    <div class="container">

            <?php include '../partes/cabecalho.php' ?>
  </div>
      <div class="row">
        <div class="col-md-4 mx-auto py-5">
          <h3>Informações do horário de Monitor</h3>
          <hr>
          <form action="" method="post" id="formulario">

            <label>Disciplina:</label><br>
            <input type="text" name="disciplica" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <label>Horário:</label><br>
            <input type="text" name="horario" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <label>Bloco:</label><br>
            <input type="text" name="bloco" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>
            <label>Sala:</label><br>
            <input type="text" name="sala" value="" class="form-control obrigatorio">
            <span class="text-danger"></span>
            <br>

            <button type="submit" class="mt-3 btn btn-primary">Confirmar Cadastro</button>
            <br>
            <!-- "Importa" os códigos/bibliotecas javascript -->
            <?php include '../partes/javascript.php' ?>

            <script type="../text/javascript">
                $(document).ready(function(){
                  // Aqui vai seu código js/jquery

                });
            </script>


  </body>
</html>
