//Espera para ativar o código quando o documento
//inteiro terminar de ser carregado
$(document).ready( function(){


  //Controlar  o envio do formulario
  $("#formulario").submit(function(event){
    //
    $(".obrigatorio").each(function(){
      var valor = $(this).val();
      //se o valor for igual a vazio
      if(valor == ""){
        //coloca uma mensagem no span
        $(this).next("span").text("Campo obrigatório!");
        //Para enviar o formulario inteiro
        event.preventDefault();

      } else{
          $(this).next("span").text("");
      } //fim do else

    }); //fim do each

  }); //fim do submit

}); //fim do ready
